#ifndef _ROS_james_msgs_BatteryStatus_h
#define _ROS_james_msgs_BatteryStatus_h

#include <stdint.h>
#include <string.h>
#include <stdlib.h>
#include "ros/msg.h"
#include "ros/time.h"

namespace james_msgs
{

  class BatteryStatus : public ros::Msg
  {
    public:
      typedef ros::Time _stamp_type;
      _stamp_type stamp;
      typedef float _voltage_type;
      _voltage_type voltage;
      typedef float _current_type;
      _current_type current;
      typedef float _temprature_type;
      _temprature_type temprature;
      typedef int8_t _status_voltage_type;
      _status_voltage_type status_voltage;
      typedef int8_t _status_current_type;
      _status_current_type status_current;
      typedef int8_t _status_temperature_type;
      _status_temperature_type status_temperature;
      typedef int8_t _status_BMS_type;
      _status_BMS_type status_BMS;
      typedef uint16_t _time_to_fill_type;
      _time_to_fill_type time_to_fill;
      typedef uint16_t _time_to_empty_type;
      _time_to_empty_type time_to_empty;
      typedef uint8_t _state_of_charge_type;
      _state_of_charge_type state_of_charge;
      typedef uint8_t _state_of_health_type;
      _state_of_health_type state_of_health;
      typedef uint16_t _remaining_capacity_type;
      _remaining_capacity_type remaining_capacity;
      typedef uint16_t _available_energy_type;
      _available_energy_type available_energy;

    BatteryStatus():
      stamp(),
      voltage(0),
      current(0),
      temprature(0),
      status_voltage(0),
      status_current(0),
      status_temperature(0),
      status_BMS(0),
      time_to_fill(0),
      time_to_empty(0),
      state_of_charge(0),
      state_of_health(0),
      remaining_capacity(0),
      available_energy(0)
    {
    }

    virtual int serialize(unsigned char *outbuffer) const
    {
      int offset = 0;
      *(outbuffer + offset + 0) = (this->stamp.sec >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (this->stamp.sec >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (this->stamp.sec >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (this->stamp.sec >> (8 * 3)) & 0xFF;
      offset += sizeof(this->stamp.sec);
      *(outbuffer + offset + 0) = (this->stamp.nsec >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (this->stamp.nsec >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (this->stamp.nsec >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (this->stamp.nsec >> (8 * 3)) & 0xFF;
      offset += sizeof(this->stamp.nsec);
      union {
        float real;
        uint32_t base;
      } u_voltage;
      u_voltage.real = this->voltage;
      *(outbuffer + offset + 0) = (u_voltage.base >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (u_voltage.base >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (u_voltage.base >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (u_voltage.base >> (8 * 3)) & 0xFF;
      offset += sizeof(this->voltage);
      union {
        float real;
        uint32_t base;
      } u_current;
      u_current.real = this->current;
      *(outbuffer + offset + 0) = (u_current.base >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (u_current.base >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (u_current.base >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (u_current.base >> (8 * 3)) & 0xFF;
      offset += sizeof(this->current);
      union {
        float real;
        uint32_t base;
      } u_temprature;
      u_temprature.real = this->temprature;
      *(outbuffer + offset + 0) = (u_temprature.base >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (u_temprature.base >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (u_temprature.base >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (u_temprature.base >> (8 * 3)) & 0xFF;
      offset += sizeof(this->temprature);
      union {
        int8_t real;
        uint8_t base;
      } u_status_voltage;
      u_status_voltage.real = this->status_voltage;
      *(outbuffer + offset + 0) = (u_status_voltage.base >> (8 * 0)) & 0xFF;
      offset += sizeof(this->status_voltage);
      union {
        int8_t real;
        uint8_t base;
      } u_status_current;
      u_status_current.real = this->status_current;
      *(outbuffer + offset + 0) = (u_status_current.base >> (8 * 0)) & 0xFF;
      offset += sizeof(this->status_current);
      union {
        int8_t real;
        uint8_t base;
      } u_status_temperature;
      u_status_temperature.real = this->status_temperature;
      *(outbuffer + offset + 0) = (u_status_temperature.base >> (8 * 0)) & 0xFF;
      offset += sizeof(this->status_temperature);
      union {
        int8_t real;
        uint8_t base;
      } u_status_BMS;
      u_status_BMS.real = this->status_BMS;
      *(outbuffer + offset + 0) = (u_status_BMS.base >> (8 * 0)) & 0xFF;
      offset += sizeof(this->status_BMS);
      *(outbuffer + offset + 0) = (this->time_to_fill >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (this->time_to_fill >> (8 * 1)) & 0xFF;
      offset += sizeof(this->time_to_fill);
      *(outbuffer + offset + 0) = (this->time_to_empty >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (this->time_to_empty >> (8 * 1)) & 0xFF;
      offset += sizeof(this->time_to_empty);
      *(outbuffer + offset + 0) = (this->state_of_charge >> (8 * 0)) & 0xFF;
      offset += sizeof(this->state_of_charge);
      *(outbuffer + offset + 0) = (this->state_of_health >> (8 * 0)) & 0xFF;
      offset += sizeof(this->state_of_health);
      *(outbuffer + offset + 0) = (this->remaining_capacity >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (this->remaining_capacity >> (8 * 1)) & 0xFF;
      offset += sizeof(this->remaining_capacity);
      *(outbuffer + offset + 0) = (this->available_energy >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (this->available_energy >> (8 * 1)) & 0xFF;
      offset += sizeof(this->available_energy);
      return offset;
    }

    virtual int deserialize(unsigned char *inbuffer)
    {
      int offset = 0;
      this->stamp.sec =  ((uint32_t) (*(inbuffer + offset)));
      this->stamp.sec |= ((uint32_t) (*(inbuffer + offset + 1))) << (8 * 1);
      this->stamp.sec |= ((uint32_t) (*(inbuffer + offset + 2))) << (8 * 2);
      this->stamp.sec |= ((uint32_t) (*(inbuffer + offset + 3))) << (8 * 3);
      offset += sizeof(this->stamp.sec);
      this->stamp.nsec =  ((uint32_t) (*(inbuffer + offset)));
      this->stamp.nsec |= ((uint32_t) (*(inbuffer + offset + 1))) << (8 * 1);
      this->stamp.nsec |= ((uint32_t) (*(inbuffer + offset + 2))) << (8 * 2);
      this->stamp.nsec |= ((uint32_t) (*(inbuffer + offset + 3))) << (8 * 3);
      offset += sizeof(this->stamp.nsec);
      union {
        float real;
        uint32_t base;
      } u_voltage;
      u_voltage.base = 0;
      u_voltage.base |= ((uint32_t) (*(inbuffer + offset + 0))) << (8 * 0);
      u_voltage.base |= ((uint32_t) (*(inbuffer + offset + 1))) << (8 * 1);
      u_voltage.base |= ((uint32_t) (*(inbuffer + offset + 2))) << (8 * 2);
      u_voltage.base |= ((uint32_t) (*(inbuffer + offset + 3))) << (8 * 3);
      this->voltage = u_voltage.real;
      offset += sizeof(this->voltage);
      union {
        float real;
        uint32_t base;
      } u_current;
      u_current.base = 0;
      u_current.base |= ((uint32_t) (*(inbuffer + offset + 0))) << (8 * 0);
      u_current.base |= ((uint32_t) (*(inbuffer + offset + 1))) << (8 * 1);
      u_current.base |= ((uint32_t) (*(inbuffer + offset + 2))) << (8 * 2);
      u_current.base |= ((uint32_t) (*(inbuffer + offset + 3))) << (8 * 3);
      this->current = u_current.real;
      offset += sizeof(this->current);
      union {
        float real;
        uint32_t base;
      } u_temprature;
      u_temprature.base = 0;
      u_temprature.base |= ((uint32_t) (*(inbuffer + offset + 0))) << (8 * 0);
      u_temprature.base |= ((uint32_t) (*(inbuffer + offset + 1))) << (8 * 1);
      u_temprature.base |= ((uint32_t) (*(inbuffer + offset + 2))) << (8 * 2);
      u_temprature.base |= ((uint32_t) (*(inbuffer + offset + 3))) << (8 * 3);
      this->temprature = u_temprature.real;
      offset += sizeof(this->temprature);
      union {
        int8_t real;
        uint8_t base;
      } u_status_voltage;
      u_status_voltage.base = 0;
      u_status_voltage.base |= ((uint8_t) (*(inbuffer + offset + 0))) << (8 * 0);
      this->status_voltage = u_status_voltage.real;
      offset += sizeof(this->status_voltage);
      union {
        int8_t real;
        uint8_t base;
      } u_status_current;
      u_status_current.base = 0;
      u_status_current.base |= ((uint8_t) (*(inbuffer + offset + 0))) << (8 * 0);
      this->status_current = u_status_current.real;
      offset += sizeof(this->status_current);
      union {
        int8_t real;
        uint8_t base;
      } u_status_temperature;
      u_status_temperature.base = 0;
      u_status_temperature.base |= ((uint8_t) (*(inbuffer + offset + 0))) << (8 * 0);
      this->status_temperature = u_status_temperature.real;
      offset += sizeof(this->status_temperature);
      union {
        int8_t real;
        uint8_t base;
      } u_status_BMS;
      u_status_BMS.base = 0;
      u_status_BMS.base |= ((uint8_t) (*(inbuffer + offset + 0))) << (8 * 0);
      this->status_BMS = u_status_BMS.real;
      offset += sizeof(this->status_BMS);
      this->time_to_fill =  ((uint16_t) (*(inbuffer + offset)));
      this->time_to_fill |= ((uint16_t) (*(inbuffer + offset + 1))) << (8 * 1);
      offset += sizeof(this->time_to_fill);
      this->time_to_empty =  ((uint16_t) (*(inbuffer + offset)));
      this->time_to_empty |= ((uint16_t) (*(inbuffer + offset + 1))) << (8 * 1);
      offset += sizeof(this->time_to_empty);
      this->state_of_charge =  ((uint8_t) (*(inbuffer + offset)));
      offset += sizeof(this->state_of_charge);
      this->state_of_health =  ((uint8_t) (*(inbuffer + offset)));
      offset += sizeof(this->state_of_health);
      this->remaining_capacity =  ((uint16_t) (*(inbuffer + offset)));
      this->remaining_capacity |= ((uint16_t) (*(inbuffer + offset + 1))) << (8 * 1);
      offset += sizeof(this->remaining_capacity);
      this->available_energy =  ((uint16_t) (*(inbuffer + offset)));
      this->available_energy |= ((uint16_t) (*(inbuffer + offset + 1))) << (8 * 1);
      offset += sizeof(this->available_energy);
     return offset;
    }

    const char * getType(){ return "james_msgs/BatteryStatus"; };
    const char * getMD5(){ return "336baae5534e5fb3c969e18b99342430"; };

  };

}
#endif